# Laxmi Aquaguard Service

Android app for personal Aquaguard customer/service records.

## Included
- English + Marathi UI
- Customer records and search
- Purchase, installation, warranty and next-service dates
- Multiple service records and service history
- Due-service screen
- WhatsApp service summary
- Local device storage
- JSON backup and restore

## Online build
This project includes a Gradle wrapper (`gradlew`, `gradlew.bat`, and `gradle/wrapper/`) and uses Android Gradle Plugin 8.7.3 with Gradle 8.9.

Build debug APK with:
`./gradlew assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`
